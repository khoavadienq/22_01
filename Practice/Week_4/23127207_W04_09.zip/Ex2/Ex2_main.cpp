#include "Ex2.h"

int main(){
    Node *head = NULL;
    readFile(head);
    removeDuplicate(head);
    printList(head);
    deleteList(head);
    return 0;
}