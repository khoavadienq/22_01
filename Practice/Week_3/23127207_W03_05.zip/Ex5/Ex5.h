#pragma once
#include <iostream>

using namespace std;

void input(int *&arr, int size);
double calMedian(int *arr, int size);