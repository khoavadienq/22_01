#pragma once 

#include <iostream>
#include <cstring>

using namespace std;
bool isPalindrome(char* cstr);