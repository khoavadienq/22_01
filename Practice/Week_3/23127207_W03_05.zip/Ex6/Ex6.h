#pragma once
#include <iostream>

using namespace std;

void inputArray(int *&arr, int size);
int *doubleArray(int *arr, int size);
void printArray(int *double_arr, int size);