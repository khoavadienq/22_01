#pragma once

using namespace std;
int doSomthing(int *&x, int *&y);